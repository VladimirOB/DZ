﻿// Шаблон учебного проекта
#include "pch.h"

int main()
{
	// настройка вывода в консоль
	SetConsoleTitle(L"Учебный проект");
	SetConsoleOutputCP(CODE_PAGE);
	system(BLUE_ON_GRAY);

	/*
	Case6.  Единицы длины пронумерованы следующим образом: 1 — дециметр,
			2 — километр, 3 — метр, 4 — миллиметр, 5 — сантиметр. Дан номер
			единицы длины (целое число в диапазоне 1–5) и длина отрезка в этих
			единицах (вещественное число). Найти длину отрезка в метрах.
	*/
	double lenght;
	double meters;
	int cmd;

	while (true)
	{
		system("cls");
		cout << "\t*** Меню ***\n";
		cout << "1. Дециметр\n";
		cout << "2. Километр\n";
		cout << "3. Метр\n";
		cout << "4. Миллиметр\n";
		cout << "5. Сантиметр\n";
		cout << "0. Выход\n";
		cout << "   Ваш выбор> ";
		cin >> cmd;

		if (cmd == 0) break;

		if (cmd < 1 || cmd > 5) {
			cout << "Ошибка! Нет такого пункта меню.\n";
			system("pause");
			continue;
		} // if

		cout << "Введите длину отрезка в этих единицах> ";
		cin >> lenght;

		if (lenght <= 0) {
			cout << "Ошибка! Длина не может быть 0 или отрицательной.\n";
			system("pause");
			continue;
		} // if

		switch (cmd)
		{
		case 1:
			meters = lenght / 10.;
			break;
		case 2:
			meters = lenght * 1000.;
			break;
		case 3:
			meters = lenght;
			break;
		case 4:
			meters = lenght / 1000.;
			break;
		case 5:
			meters = lenght / 100.;
			break;
		} // switch
		cout << "Длина отрезка в метрах = " << meters << endl;
		system("pause");
		// system("pause>nul");
	} // while

	cout << "\nНажмите клавишу <Enter> для продолжения. . .";
	cin.ignore(1, '\n');   // пропустить ввод одного символа Enter, оставшегося
						   // в буфере ввода после ввода чисел
	cin.get();             // ждать ввода символов и нажатия <Enter>
	system(CLEAR);
	system(GRAY_ON_BLACK);

	return 0;
} // main