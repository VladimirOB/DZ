﻿// Шаблон учебного проекта
#include "pch.h"

int main()
{
	// настройка вывода в консоль
	SetConsoleTitle(L"Учебный проект");
	SetConsoleOutputCP(CODE_PAGE);
	system(BLUE_ON_GRAY);

	/*
	Case5.  Арифметические действия над числами пронумерованы следующим
			образом: + — сложение, - — вычитание, * — умножение, / — деление. Дан
			символ действия и вещественные числа A и B (B не равно 0). 
			Выполнить над числами указанное действие и вывести результат.
	*/
	double a, b;         // операнды
	double result = 0.;  // результат
	char operation;      // операция

	while (true)
	{
		cout << "Введите число1 знак операции число2 (+, -, *, /, # - выход)> ";
		cin >> a >> operation >> b;

		if (operation == '#') break;

		switch (operation)
		{
		case '+':
			result = a + b;
			break;
		case '-':
			result = a - b;
			break;
		case '*':
			result = a * b;
			break;
		case '/':
			if (b != 0)
				result = a / b;
			else
				cout << "Ошибка! Делить на 0 нельзя.\n";
			break;
		default:
			cout << "Ошибка! Данная операция не поддерживается.\n";
			break;
		} // switch
		cout << a << " " << operation << " " << b << " = " << result << "\n";
	} // while


	cout << "\nНажмите клавишу <Enter> для продолжения. . .";
	cin.ignore(1, '\n');   // пропустить ввод одного символа Enter, оставшегося
						   // в буфере ввода после ввода чисел
	cin.get();             // ждать ввода символов и нажатия <Enter>
	system(CLEAR);
	system(GRAY_ON_BLACK);

	return 0;
} // main