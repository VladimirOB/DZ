﻿#ifndef PCH_H
#define PCH_H

// использование математических констант, современный стиль
#include <corecrt_math_defines.h>

#include <iostream>  // этот файл делает доступными инженерные функции  
#include <iomanip>   // для манипуляторов вывода setw(), setprecision()
#include <Windows.h>

using namespace std;

// объявление символической константы - кодовой страницы
#define CODE_PAGE 1251

// объявление константы - команды включения цвета в консоли
// светло-желтые буквы на светло-сиреневом фоне
#define YELLOW_ON_LTMAGENTA "color de"
#define BLUE_ON_GRAY        "color 71"

// объявление константы - команды включения цвета в консоли
// серые буквы на черном фоне
#define GRAY_ON_BLACK "color 07"

// для единообразия кодируем такде команду очистки консоли
#define CLEAR "cls"

#endif //PCH_H
